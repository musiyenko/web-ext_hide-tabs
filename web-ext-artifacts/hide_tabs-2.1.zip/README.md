## What is it?
**Hide tabs** is a web extension for Firefox

## What it does
Hide tabs allows you to quickly hide and restore all tabs

## How to use
Click on the "Hide tabs" icon or use the shortcut `CTRL+SHIFT+Q`

## Requirements
Minumum FF version supported is **63.0**

## Localizations
* English
* Italian
* Russian
